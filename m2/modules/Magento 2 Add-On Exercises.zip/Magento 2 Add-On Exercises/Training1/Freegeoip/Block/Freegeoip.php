<?php
namespace Training1\Freegeoip\Block;

class Freegeoip extends \Magento\Framework\View\Element\Template
{
}
