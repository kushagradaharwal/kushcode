<?php
namespace Training3\BundleBlock\Block;

class BundleBlock extends \Magento\Framework\View\Element\Template
{

}
